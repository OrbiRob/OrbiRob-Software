#!/usr/bin/python3
"""Application-independent calibration and emergency-stop service."""
import argparse
import json
import math
import os
from pathlib import Path
import zlib
import yaml
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
from std_msgs.msg import Bool, Float32MultiArray, UInt32, String
from std_srvs.srv import Trigger


def load_configuration(path):
    data = yaml.safe_load(Path(path).read_text())
    drive = data['drive']
    geometry = [float(drive[key]) for key in
                ('left_meters_per_tick', 'right_meters_per_tick', 'wheel_separation_m')]
    if any(not math.isfinite(v) or v <= 0 for v in geometry):
        raise ValueError('Drive calibration must contain finite positive values')
    # Ticks/revolution is diagnostic metadata only; 1 marks unspecified metadata.
    ticks = int(drive.get('encoder_ticks_per_revolution', data.get('encoder_ticks_per_revolution', 1)))
    if not 1 <= ticks <= 16777215:
        raise ValueError('encoder_ticks_per_revolution must be 1..16777215')
    version = (zlib.crc32(json.dumps([ticks] + geometry).encode()) & 0xffffff) or 1
    return [float(version), float(ticks)] + geometry


class StopLatch:
    def __init__(self, path):
        self.path = Path(path)
        self.active = bool(json.loads(self.path.read_text())['active']) if self.path.exists() else False
        self.previous_request = None

    def set(self, active):
        if self.active == active:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix('.tmp')
        with temporary.open('w') as stream:
            json.dump({'active': active}, stream)
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(self.path)
        self.active = active

    def request(self, active):
        if active:
            self.set(True)
        elif self.previous_request is True:
            self.set(False)  # explicit operator true -> false; idle false cannot clear a fault
        self.previous_request = active


class BaseService(Node):
    def __init__(self, calibration, state_file):
        super().__init__('orbirob_base')
        self.configuration = load_configuration(calibration)
        self.latch = StopLatch(state_file)
        self.ack = None
        durable = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                             durability=DurabilityPolicy.TRANSIENT_LOCAL)
        reliable = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE)
        self.state_pub = self.create_publisher(Bool, '/orbirob/emergency_stop_active', durable)
        self.config_pub = self.create_publisher(Float32MultiArray, '/pico/drive_config', reliable)
        self.version_pub = self.create_publisher(String, '/orbirob/base/version', durable)
        self.create_subscription(Bool, '/emergency_stop', self.ui_request, reliable)
        self.create_subscription(Bool, '/orbirob/arbiter_stop', self.arbiter_stop, reliable)
        self.create_subscription(UInt32, '/pico/drive_config_status', self.config_ack,
                                 QoSProfile(depth=1, reliability=ReliabilityPolicy.BEST_EFFORT))
        self.create_service(Trigger, '/orbirob/safety/stop', self.stop_service)
        self.create_service(Trigger, '/orbirob/safety/reset', self.reset_service)
        self.create_timer(0.1, self.publish_state)
        self.create_timer(1.0, self.publish_config)
        self.publish_state()
        self.publish_config()

    def ui_request(self, msg):
        self.latch.request(msg.data)
        self.publish_state()

    def arbiter_stop(self, msg):
        if msg.data:
            self.latch.set(True)
            self.publish_state()

    def config_ack(self, msg):
        self.ack = msg.data

    def publish_config(self):
        if self.ack != int(self.configuration[0]):
            msg = Float32MultiArray()
            msg.data = self.configuration
            self.config_pub.publish(msg)

    def publish_state(self):
        msg = Bool()
        msg.data = self.latch.active
        self.state_pub.publish(msg)
        version = String()
        version.data = '1.0.0'
        self.version_pub.publish(version)

    def stop_service(self, request, response):
        self.latch.set(True)
        self.publish_state()
        response.success = True
        response.message = 'Emergency stop latched'
        return response

    def reset_service(self, request, response):
        if self.latch.previous_request is True:
            response.success = False
            response.message = 'Release the TFT stop request first'
        else:
            self.latch.set(False)
            self.publish_state()
            response.success = True
            response.message = 'Emergency stop reset; fresh command required'
        return response


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--calibration', required=True)
    parser.add_argument('--state-file', default='/var/lib/orbirob/emergency_stop.json')
    args, ros_args = parser.parse_known_args()
    rclpy.init(args=ros_args)
    node = BaseService(args.calibration, args.state_file)
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
