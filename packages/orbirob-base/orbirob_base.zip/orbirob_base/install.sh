#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then
  echo 'Run with sudo: sudo bash install.sh /absolute/path/calibration.yaml [--install-agent]'
  exit 1
fi
calibration_path=${1:?Supply the existing calibration.yaml path}
agent_option=${2:-}
robot_user=${SUDO_USER:-orbirob}
robot_home=$(getent passwd "$robot_user" | cut -d: -f6)
script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
[[ -f "$calibration_path" && -f /opt/ros/jazzy/setup.bash ]]
[[ -z "$agent_option" || "$agent_option" == --install-agent ]]
# Validate the file before replacing the running service's configuration.
/usr/bin/python3 - "$script_dir" "$calibration_path" <<'PY'
import ast, pathlib, sys
namespace = {}
source = pathlib.Path(sys.argv[1], 'base_service.py').read_text()
tree = ast.parse(source)
keep = [n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom))
        and not (isinstance(n, ast.Import) and any(x.name == 'rclpy' for x in n.names))
        and not (isinstance(n, ast.ImportFrom) and n.module.startswith(('rclpy', 'std_msgs', 'std_srvs')))]
keep += [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'load_configuration']
exec(compile(ast.Module(body=keep, type_ignores=[]), '<calibration validation>', 'exec'), namespace)
namespace['load_configuration'](sys.argv[2])
PY
install -d /opt/orbirob/base /etc/orbirob
install -d -o "$robot_user" -g "$(id -gn "$robot_user")" /var/lib/orbirob
install -m 755 "$script_dir/base_service.py" /opt/orbirob/base/base_service.py
install -m 644 "$calibration_path" /etc/orbirob/calibration.yaml
cat > /opt/orbirob/base/run.sh <<'EOF'
#!/usr/bin/env bash
set -e
source /opt/ros/jazzy/setup.bash
exec /usr/bin/python3 /opt/orbirob/base/base_service.py --calibration /etc/orbirob/calibration.yaml
EOF
chmod 755 /opt/orbirob/base/run.sh
cat > /etc/systemd/system/orbirob-base.service <<EOF
[Unit]
Description=OrbiRob base calibration and emergency stop
After=network.target
[Service]
Type=simple
User=$robot_user
EnvironmentFile=-/etc/orbirob/ros.env
ExecStart=/opt/orbirob/base/run.sh
Restart=on-failure
RestartSec=2
[Install]
WantedBy=multi-user.target
EOF
if [[ "$agent_option" == --install-agent ]]; then
  [[ -f "$robot_home/microros_ws/install/setup.bash" ]]
  # Opt-in only: do not enable this if another agent service already exists.
  cat > /opt/orbirob/base/run_agent.sh <<'EOF'
#!/usr/bin/env bash
set -e
source /opt/ros/jazzy/setup.bash
source "$HOME/microros_ws/install/setup.bash"
exec ros2 run micro_ros_agent micro_ros_agent serial --dev /dev/ttyACM0
EOF
  chmod 755 /opt/orbirob/base/run_agent.sh
  cat > /etc/systemd/system/orbirob-agent.service <<EOF
[Unit]
Description=OrbiRob Pico micro-ROS agent
After=network.target
[Service]
User=$robot_user
Environment=HOME=$robot_home
EnvironmentFile=-/etc/orbirob/ros.env
ExecStart=/opt/orbirob/base/run_agent.sh
Restart=always
RestartSec=2
[Install]
WantedBy=multi-user.target
EOF
fi
systemctl daemon-reload
systemctl enable --now orbirob-base.service
systemctl restart orbirob-base.service
if [[ "$agent_option" == --install-agent ]]; then
  systemctl enable --now orbirob-agent.service
fi
echo 'Base service installed. Keep one micro-ROS agent at boot. Bringup is optional.'
echo 'Use the same ROS_DOMAIN_ID for boot services and developer applications.'
