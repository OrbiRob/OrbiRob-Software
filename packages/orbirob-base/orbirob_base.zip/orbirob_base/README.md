# OrbiRob base services 1.0.0

Bringup is an optional application. At boot, the micro-ROS agent, this base service, and TFT UI run independently. No ROS workspace build is required for this service.

Install together with Pico 1.2.0, arbiter 1.2.0 (if using arbiter), and TFT UI 1.3.0. GUI 1.1.0 remains compatible. Stop bringup and keep wheels raised during installation.

## Install

On Ubuntu 24.04 with ROS Jazzy, ensure `python3-yaml` and ROS `rclpy`, `std_msgs`, and `std_srvs` are installed. Extract this archive, then pass the actual existing calibration file:

```bash
sudo bash install.sh /absolute/path/to/calibration.yaml
```

This creates/enables `orbirob-base.service`. Keep your existing micro-ROS agent service enabled. If no agent service exists, use the optional second argument `--install-agent`; do not create a second agent for the same serial port. The optional agent wrapper sources `$HOME/microros_ws/install/setup.bash` and uses `/dev/ttyACM0`.

Calibration is copied to `/etc/orbirob/calibration.yaml`. Edit this authoritative copy and restart `orbirob-base.service` to apply updates. Do not run an application calibration publisher with conflicting settings. Such a publisher is not part of the provided bringup archive, so its existing launch must be checked on the robot. Identical repeated calibration is harmless in the new Pico firmware.

All ROS processes must share ROS_DOMAIN_ID and DDS discovery settings. Optional `/etc/orbirob/ros.env` may contain e.g. `ROS_DOMAIN_ID=0`; use your actual deployment value. These services do not inherit interactive shell settings.

Calibration format:

```yaml
drive:
  left_meters_per_tick: 0.0000436332313
  right_meters_per_tick: 0.0000436332313
  wheel_separation_m: 0.289
```

Optional `drive.encoder_ticks_per_revolution` is diagnostic metadata. When absent, the service sends 1 as an unspecified metadata placeholder; actual velocity conversion uses meters_per_tick. Version is generated from the settings, fits exactly into Float32, and calibration is retried until the Pico acknowledges it. Pico telemetry with a new/zero version after reconnect restarts delivery.

## Developer API

After boot, without launching bringup:

```bash
source /opt/ros/jazzy/setup.bash
ros2 topic pub -r 20 /cmd_vel geometry_msgs/msg/Twist '{linear: {x: 0.05}, angular: {z: 0.0}}'
```

Ctrl+C stops publication; Pico's independent 500 ms watchdog disables motors. Motors also stop on micro-ROS disconnect. They may resume on a fresh command after reconnect, unless emergency stop was latched.

```bash
ros2 service call /orbirob/safety/stop std_srvs/srv/Trigger '{}'
ros2 service call /orbirob/safety/reset std_srvs/srv/Trigger '{}'
```

The TFT publishes `/emergency_stop` requests; an explicit true→false gesture resets. Repeated false heartbeat messages do not clear a service/arbiter stop. Reset service refuses while the TFT request is active. `/orbirob/emergency_stop_active` is the authoritative Bool, published only by the base service. Stop latch is stored in `/var/lib/orbirob/emergency_stop.json` and restored across base service/host restarts. Initial installation boots released. Software reset may allow a continuously publishing application to resume; stop that publisher before resetting if unwanted.

The optional arbiter consumes authoritative stop state and emits `/orbirob/arbiter_stop` true events for service/fault stops. It stays silent on `/cmd_vel` while idle. Use one movement source at a time. Arbiter autonomy still needs explicit enable after stop/mode changes.

Pico requires calibration but does not require a continuous arbiter/base safety heartbeat to accept velocity. Thus loss of base/TFT alone does not stop an independently live developer velocity publisher. Emergency-stop functionality needs those services running and connected; this is a software stop, not a physical motor-power interrupt. The 500 ms command watchdog remains independent of them.

## Verify

```bash
systemctl status orbirob-base.service
ros2 topic echo /pico/drive_config_status
ros2 topic echo /orbirob/emergency_stop_active
```

With raised wheels: verify direct velocity without bringup, positive forward wheel feedback, publisher cutoff, TFT latch/reset while velocity publisher continues, retained stop after base service restart, and calibration after Pico reboot/reconnect. Full ROS/hardware deployment remains to be tested.
