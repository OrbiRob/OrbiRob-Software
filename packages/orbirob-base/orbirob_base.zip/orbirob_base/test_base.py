#!/usr/bin/python3
import ast
from pathlib import Path
import tempfile
import json
source = Path(__file__).with_name('base_service.py').read_text()
tree = ast.parse(source)
keep = [n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom))
        and not (isinstance(n, ast.Import) and any(x.name == 'rclpy' for x in n.names))
        and not (isinstance(n, ast.ImportFrom) and n.module.startswith(('rclpy', 'std_msgs', 'std_srvs')))]
keep += [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'load_configuration'
         or isinstance(n, ast.ClassDef) and n.name == 'StopLatch']
ns = {}
exec(compile(ast.Module(body=keep, type_ignores=[]), '<base>', 'exec'), ns)
with tempfile.TemporaryDirectory() as directory:
    state = Path(directory, 'state.json')
    latch = ns['StopLatch'](state)
    assert not latch.active
    latch.request(False)
    latch.set(True)
    for _ in range(30): latch.request(False)
    assert latch.active
    assert ns['StopLatch'](state).active
    latch.request(True);latch.request(False)
    assert not latch.active and not ns['StopLatch'](state).active
    calibration = Path(directory, 'calibration.yaml')
    calibration.write_text('drive:\n  left_meters_per_tick: 0.0000436332313\n  right_meters_per_tick: 0.0000436332313\n  wheel_separation_m: 0.289\n')
    config = ns['load_configuration'](calibration)
    assert len(config) == 5 and 1 <= config[0] <= 16777215 and config[1] == 1
    assert config == ns['load_configuration'](calibration)
    calibration.write_text(calibration.read_text().replace('0.289', '0.290'))
    assert ns['load_configuration'](calibration)[0] != config[0]
    calibration.write_text(calibration.read_text().replace('0.290', '-1'))
    try: ns['load_configuration'](calibration)
    except ValueError: pass
    else: raise AssertionError('Invalid calibration accepted')
print('PASS: initial readiness, persistent stop, heartbeat cannot reset latch, explicit reset, configuration validation/version')
