#!/usr/bin/env bash
#
# install_orbirob_hailo.sh
#
# OrbiRob - Raspberry Pi 5 / Ubuntu 24.04 / Raspberry Pi AI HAT+ (Hailo-8L)
#
# Pinned software baseline:
#   HailoRT / PCIe driver / HailoRT Python binding : 4.24.0
#   TAPPAS source tree                              : bundled ./tappas/
#   TAPPAS Python binding                          : 5.4.0 (optional bundled wheel)
#
# Expected layout:
#
#   rpi_ai_hat_package/
#   ├── install_orbirob_hailo.sh
#   ├── packages/
#   │   ├── hailort-pcie-driver_4.24.0*.deb
#   │   ├── hailort_4.24.0*_arm64.deb
#   │   ├── hailort-4.24.0-cp312-cp312-linux_aarch64.whl
#   │   └── hailo_tappas_core_python_binding-5.4.0-*.whl   [optional]
#   |   |__ orbirob-tappas-core_5.4.0_arm64.deb
#   │   
#   └── hailo-apps/                                      [not installed here]
#
# Notes:
#   - Run as root: sudo ./install_orbirob_hailo.sh
#   - Ubuntu repository access is used for non-Hailo dependencies.
#   - The Hailo-specific .deb/.whl files are installed only from ./packages.
#   - The installer is intended to be safe to run more than once.
#
set -Eeuo pipefail

EXPECTED_HAILORT="4.24.0"
EXPECTED_TAPPAS_PY="5.4.0"

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_DIR="${SCRIPT_DIR}/packages"

HAILO_VENV="/opt/hailo/venv"
PROFILE_FILE="/etc/profile.d/hailo-orbirob.sh"
MODPROBE_FILE="/etc/modprobe.d/hailo_pci.conf"
CONSTRAINTS_FILE="/tmp/orbirob_hailo_constraints.txt"

REBOOT_REQUIRED=0

# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

log()
{
    echo
    echo "======================================================================"
    echo "$*"
    echo "======================================================================"
}

info()
{
    echo "[INFO] $*"
}

warn()
{
    echo "[WARN] $*" >&2
}

die()
{
    echo "[ERROR] $*" >&2
    exit 1
}

on_error()
{
    local exit_code=$?
    local line_no=${1:-unknown}
    echo
    echo "[ERROR] Installation failed at line ${line_no} (exit ${exit_code})." >&2
    echo "[ERROR] Fix the reported problem and run this script again." >&2
    exit "${exit_code}"
}
trap 'on_error $LINENO' ERR

require_root()
{
    [[ ${EUID} -eq 0 ]] || die "Run with sudo: sudo ./$(basename "$0")"
}

single_match()
{
    local pattern="$1"
    local description="$2"
    local matches=()

    shopt -s nullglob
    matches=( "${PACKAGE_DIR}"/${pattern} )
    shopt -u nullglob

    if (( ${#matches[@]} == 0 )); then
        die "Missing ${description}. Expected a file matching:
  ${PACKAGE_DIR}/${pattern}"
    fi

    if (( ${#matches[@]} > 1 )); then
        echo "[ERROR] More than one file matches ${description}:" >&2
        printf '  %s\n' "${matches[@]}" >&2
        die "Keep exactly one matching package in ${PACKAGE_DIR}."
    fi

    printf '%s\n' "${matches[0]}"
}

optional_single_match()
{
    local pattern="$1"
    local matches=()

    shopt -s nullglob
    matches=( "${PACKAGE_DIR}"/${pattern} )
    shopt -u nullglob

    if (( ${#matches[@]} == 0 )); then
        printf '\n'
        return 0
    fi

    if (( ${#matches[@]} > 1 )); then
        echo "[ERROR] More than one optional file matches ${pattern}:" >&2
        printf '  %s\n' "${matches[@]}" >&2
        die "Keep at most one matching package in ${PACKAGE_DIR}."
    fi

    printf '%s\n' "${matches[0]}"
}

deb_version()
{
    dpkg-deb -f "$1" Version | sed -E 's/^[0-9]+://; s/[-+~].*$//'
}

wheel_version()
{
    local filename
    filename="$(basename "$1")"
    printf '%s\n' "${filename}" | sed -E 's/^[^-]+-([0-9]+\.[0-9]+\.[0-9]+).*/\1/'
}

package_installed_version()
{
    local pkg="$1"
    dpkg-query -W -f='${Version}\n' "${pkg}" 2>/dev/null || true
}

# -----------------------------------------------------------------------------
# Basic checks
# -----------------------------------------------------------------------------

require_root

log "OrbiRob Hailo installer - system checks"

[[ -d "${PACKAGE_DIR}" ]] || die "Package directory not found: ${PACKAGE_DIR}"

ARCH="$(dpkg --print-architecture)"
[[ "${ARCH}" == "arm64" ]] || die "Expected arm64, detected '${ARCH}'."

[[ -r /etc/os-release ]] || die "/etc/os-release not found."
# shellcheck disable=SC1091
source /etc/os-release

[[ "${ID:-}" == "ubuntu" ]] || die "Expected Ubuntu, detected '${ID:-unknown}'."

if [[ "${VERSION_ID:-}" != "24.04" ]]; then
    warn "This installer is validated for Ubuntu 24.04; detected ${VERSION_ID:-unknown}."
fi

MODEL="$(tr -d '\0' </proc/device-tree/model 2>/dev/null || true)"
if [[ "${MODEL}" != *"Raspberry Pi 5"* ]]; then
    warn "Raspberry Pi 5 could not be confirmed. Detected model: ${MODEL:-unknown}"
else
    info "Hardware: ${MODEL}"
fi

PYVER="$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")' 2>/dev/null || true)"
[[ "${PYVER}" == "3.12" ]] || die "Expected system Python 3.12 on Ubuntu 24.04; detected '${PYVER:-none}'."

info "Ubuntu: ${PRETTY_NAME:-Ubuntu}"
info "Kernel: $(uname -r)"
info "Architecture: ${ARCH}"
info "Python: $(python3 --version 2>&1)"

# -----------------------------------------------------------------------------
# Locate bundled Hailo packages
# -----------------------------------------------------------------------------

log "Locating bundled Hailo packages"

PCIE_DEB="$(single_match "hailort-pcie-driver_${EXPECTED_HAILORT}*.deb" "HailoRT PCIe driver ${EXPECTED_HAILORT}")"
HAILORT_DEB="$(single_match "hailort_${EXPECTED_HAILORT}*_arm64.deb" "HailoRT runtime ${EXPECTED_HAILORT}")"
HAILORT_WHL="$(single_match "hailort-${EXPECTED_HAILORT}-cp312-cp312-linux_aarch64.whl" "HailoRT Python wheel ${EXPECTED_HAILORT}")"
TAPPAS_WHL="$(optional_single_match "hailo_tappas_core_python_binding-${EXPECTED_TAPPAS_PY}-*.whl")"
TAPPAS_DEB="$(single_match \
    "orbirob-tappas-core_${EXPECTED_TAPPAS_PY}_arm64.deb" \
    "OrbiRob TAPPAS Core ${EXPECTED_TAPPAS_PY}")"
    
printf '  %-24s %s\n' "PCIe driver:" "$(basename "${PCIE_DEB}")"
printf '  %-24s %s\n' "HailoRT runtime:" "$(basename "${HAILORT_DEB}")"
printf '  %-24s %s\n' "TAPPAS Core:" "$(basename "${TAPPAS_DEB}")"
printf '  %-24s %s\n' "HailoRT Python:" "$(basename "${HAILORT_WHL}")"

if [[ -n "${TAPPAS_WHL}" ]]; then
    printf '  %-24s %s\n' "TAPPAS Python:" "$(basename "${TAPPAS_WHL}")"
else
    info "No bundled TAPPAS Python wheel found; TAPPAS Core will still be installed."
fi

# -----------------------------------------------------------------------------
# Validate package versions before changing the system
# -----------------------------------------------------------------------------

log "Validating bundled package versions"

DRIVER_VER="$(deb_version "${PCIE_DEB}")"
RUNTIME_VER="$(deb_version "${HAILORT_DEB}")"
HAILORT_WHEEL_VER="$(wheel_version "${HAILORT_WHL}")"
TAPPAS_DEB_VER="$(deb_version "${TAPPAS_DEB}")"

    
printf '  %-24s %s\n' "PCIe driver:" "${DRIVER_VER}"
printf '  %-24s %s\n' "HailoRT runtime:" "${RUNTIME_VER}"
printf '  %-24s %s\n' "HailoRT Python:" "${HAILORT_WHEEL_VER}"
printf '  %-24s %s\n' "Tappas Core: " "${TAPPAS_DEB_VER}"

[[ "${DRIVER_VER}" == "${EXPECTED_HAILORT}" ]] ||
    die "PCIe driver must be ${EXPECTED_HAILORT}, found ${DRIVER_VER}."

[[ "${RUNTIME_VER}" == "${EXPECTED_HAILORT}" ]] ||
    die "HailoRT runtime must be ${EXPECTED_HAILORT}, found ${RUNTIME_VER}."

[[ "${HAILORT_WHEEL_VER}" == "${EXPECTED_HAILORT}" ]] ||
    die "HailoRT Python wheel must be ${EXPECTED_HAILORT}, found ${HAILORT_WHEEL_VER}."

[[ "${TAPPAS_DEB_VER}" == "${EXPECTED_TAPPAS_PY}" ]] ||
    die "TAPPAS Core must be ${EXPECTED_TAPPAS_PY}, found ${TAPPAS_DEB_VER}."


if [[ -n "${TAPPAS_WHL}" ]]; then
    TAPPAS_WHEEL_VER="$(wheel_version "${TAPPAS_WHL}")"
    printf '  %-24s %s\n' "TAPPAS Python:" "${TAPPAS_WHEEL_VER}"
    [[ "${TAPPAS_WHEEL_VER}" == "${EXPECTED_TAPPAS_PY}" ]] ||
        die "TAPPAS Python wheel must be ${EXPECTED_TAPPAS_PY}, found ${TAPPAS_WHEEL_VER}."
fi


# -----------------------------------------------------------------------------
# Ubuntu dependencies
# -----------------------------------------------------------------------------

log "Updating APT metadata"
export DEBIAN_FRONTEND=noninteractive
apt-get update

log "Installing Ubuntu build, PCIe, Python and GStreamer dependencies"

COMMON_PACKAGES=(
    build-essential
    dkms
    pciutils
    usbutils
    git
    cmake
    pkg-config
    rsync
    curl
    wget
    python3
    python3-dev
    python3-pip
    python3-venv
    python3-setuptools
    python3-wheel
    python3-gi
    python3-gi-cairo
    python3-cffi
    gstreamer1.0-tools
    gstreamer1.0-plugins-base
    gstreamer1.0-plugins-good
    gstreamer1.0-plugins-bad
    gstreamer1.0-plugins-ugly
    gstreamer1.0-libav
    gstreamer1.0-gl
    libgstreamer1.0-dev
    libgstreamer-plugins-base1.0-dev
    gir1.2-gstreamer-1.0
    gir1.2-gst-plugins-base-1.0
    ffmpeg
    libzmq3-dev
    rapidjson-dev
    x11-utils
)

apt-get install -y "${COMMON_PACKAGES[@]}"

# Ubuntu Raspberry Pi kernels are normally covered by linux-headers-raspi.
# Prefer exact running-kernel headers if available, otherwise use the raspi meta-package.
if apt-cache show "linux-headers-$(uname -r)" >/dev/null 2>&1; then
    apt-get install -y "linux-headers-$(uname -r)"
else
    info "Exact kernel-header package not found in APT; installing linux-headers-raspi."
    apt-get install -y linux-headers-raspi
fi

# -----------------------------------------------------------------------------
# Install Hailo .deb packages
# -----------------------------------------------------------------------------

log "Installing HailoRT PCIe driver ${EXPECTED_HAILORT}"
apt-get install -y "${PCIE_DEB}"

log "Installing HailoRT runtime ${EXPECTED_HAILORT}"
apt-get install -y "${HAILORT_DEB}"

log "Installing OrbiRob TAPPAS Core ${EXPECTED_TAPPAS_PY}"
apt-get install -y "${TAPPAS_DEB}"

# -----------------------------------------------------------------------------
# Raspberry Pi / aarch64 Hailo PCIe module configuration
# -----------------------------------------------------------------------------

log "Configuring Hailo PCIe driver"

if [[ ! -f "${MODPROBE_FILE}" ]] || ! grep -q 'force_desc_page_size=4096' "${MODPROBE_FILE}"; then
    cat >"${MODPROBE_FILE}" <<'EOF'
# OrbiRob / Raspberry Pi 5 Hailo PCIe configuration
options hailo_pci force_desc_page_size=4096
EOF
    info "Created ${MODPROBE_FILE}"
    REBOOT_REQUIRED=1
else
    info "${MODPROBE_FILE} already contains the required setting."
fi

depmod -a
ldconfig
udevadm control --reload-rules || true
udevadm trigger || true

# Try to apply the module setting immediately. If the device/module is in use,
# leave it for the next reboot.
if lsmod | grep -q '^hailo_pci '; then
    if modprobe -r hailo_pci 2>/dev/null && modprobe hailo_pci 2>/dev/null; then
        info "Reloaded hailo_pci with current configuration."
    else
        warn "hailo_pci is currently in use; new module options will apply after reboot."
        REBOOT_REQUIRED=1
    fi
else
    if modprobe hailo_pci 2>/dev/null; then
        info "Loaded hailo_pci."
    else
        warn "hailo_pci could not be loaded yet. A reboot may be required."
        REBOOT_REQUIRED=1
    fi
fi

# -----------------------------------------------------------------------------
# Python virtual environment and Hailo/TAPPAS installation
# -----------------------------------------------------------------------------

log "Creating/updating dedicated Hailo Python environment"

mkdir -p "$(dirname "${HAILO_VENV}")"

if [[ ! -x "${HAILO_VENV}/bin/python" ]]; then
    python3 -m venv --system-site-packages "${HAILO_VENV}"
    info "Created ${HAILO_VENV}"
else
    info "Using existing ${HAILO_VENV}"
fi

# Do not upgrade setuptools without a bound:
# colcon-core requires setuptools < 80.
"${HAILO_VENV}/bin/python" -m pip install --upgrade pip wheel

# Prevent Hailo/TAPPAS wheel installation from pulling in NumPy 2.x and
# prevent setuptools from moving beyond the colcon-compatible range.
cat >"${CONSTRAINTS_FILE}" <<'EOF'
numpy==1.26.4
setuptools==79.0.1
cffi
EOF

log "Pinning Python dependencies for Ubuntu 24.04 / ROS 2 compatibility"

"${HAILO_VENV}/bin/python" -m pip install     --constraint "${CONSTRAINTS_FILE}"     "numpy==1.26.4"     "setuptools==79.0.1"     "cffi"

log "Installing HailoRT Python binding ${EXPECTED_HAILORT}"

"${HAILO_VENV}/bin/python" -m pip install     --constraint "${CONSTRAINTS_FILE}"     "${HAILORT_WHL}"

# -----------------------------------------------------------------------------
# Install TAPPAS Core from bundled source tree
# -----------------------------------------------------------------------------



# -----------------------------------------------------------------------------
# Optional TAPPAS Python binding
# -----------------------------------------------------------------------------

if [[ -n "${TAPPAS_WHL}" ]]; then
    log "Installing bundled TAPPAS Python binding ${EXPECTED_TAPPAS_PY}"

    "${HAILO_VENV}/bin/python" -m pip install         --constraint "${CONSTRAINTS_FILE}"         "${TAPPAS_WHL}"
else
    warn "TAPPAS Python binding wheel ${EXPECTED_TAPPAS_PY} is not bundled."
    warn "TAPPAS Core installation has still been performed."
fi

# Re-enforce known-compatible package versions after Hailo/TAPPAS installation.
log "Re-checking pinned Python package versions"

"${HAILO_VENV}/bin/python" -m pip install     --constraint "${CONSTRAINTS_FILE}"     "numpy==1.26.4"     "setuptools==79.0.1"     "cffi"

# Because this venv uses --system-site-packages, pip check can report conflicts
# inherited from Ubuntu/ROS packages. Report them, but do not abort installation.
log "Checking Python dependencies"

if ! "${HAILO_VENV}/bin/python" -m pip check; then
    warn "pip check reported dependency conflicts."
    warn "The installer will continue; review the messages above."
fi

# Refresh GStreamer caches so newly installed TAPPAS plugins are rediscovered.
log "Refreshing GStreamer cache"

rm -rf /root/.cache/gstreamer-1.0 || true

if [[ -n "${SUDO_USER:-}" && "${SUDO_USER}" != "root" ]]; then
    USER_HOME="$(getent passwd "${SUDO_USER}" | cut -d: -f6 || true)"
    if [[ -n "${USER_HOME}" ]]; then
        rm -rf "${USER_HOME}/.cache/gstreamer-1.0" || true
    fi
fi

# -----------------------------------------------------------------------------
# Environment helpers
# -----------------------------------------------------------------------------

log "Creating Hailo shell helpers"

cat >"${PROFILE_FILE}" <<EOF
# OrbiRob Hailo environment
export HAILO_VENV="${HAILO_VENV}"
EOF

cat >/usr/local/bin/hailo-python <<EOF
#!/usr/bin/env bash
exec "${HAILO_VENV}/bin/python" "\$@"
EOF
chmod 0755 /usr/local/bin/hailo-python

cat >/usr/local/bin/hailo-verify <<'EOF'
#!/usr/bin/env bash
set +e

echo "=== Hailo PCI device ==="
lspci -nn | grep -i hailo
echo

echo "=== Hailo device nodes ==="
ls -l /dev/hailo* 2>/dev/null
echo

echo "=== Hailo kernel module ==="
lsmod | grep -E '^hailo(_pci|1x_pci)'
echo

echo "=== Hailo packages ==="
dpkg-query -W 'hailort*' 2>/dev/null
echo

echo "=== hailortcli ==="
command -v hailortcli
hailortcli --version 2>/dev/null
echo

echo "=== Device identify ==="
hailortcli fw-control identify 2>/dev/null
echo

echo "=== Python environment ==="
/opt/hailo/venv/bin/python - <<'PY'
try:
    import numpy
    print("numpy:", numpy.__version__)
except Exception as exc:
    print("numpy: FAILED:", exc)

try:
    import setuptools
    print("setuptools:", setuptools.__version__)
except Exception as exc:
    print("setuptools: FAILED:", exc)

try:
    import cffi
    print("cffi:", cffi.__version__)
except Exception as exc:
    print("cffi: FAILED:", exc)

try:
    import hailo_platform
    print("hailo_platform: OK")
    print("location:", hailo_platform.__file__)
except Exception as exc:
    print("hailo_platform: FAILED")
    print(exc)
PY
echo

echo "=== pip check ==="
/opt/hailo/venv/bin/python -m pip check
echo

echo "=== GStreamer Hailo elements ==="
gst-inspect-1.0 hailonet >/dev/null 2>&1
echo "hailonet: $([[ $? -eq 0 ]] && echo OK || echo NOT FOUND)"

gst-inspect-1.0 hailotools >/dev/null 2>&1
echo "hailotools: $([[ $? -eq 0 ]] && echo OK || echo NOT FOUND)"
EOF
chmod 0755 /usr/local/bin/hailo-verify

# -----------------------------------------------------------------------------
# Verification
# -----------------------------------------------------------------------------

log "Installation verification"

echo
echo "--- Installed Debian packages ---"
for pkg in hailort-pcie-driver hailort; do
    installed="$(package_installed_version "${pkg}")"
    printf '  %-24s %s\n' "${pkg}" "${installed:-NOT INSTALLED}"
done

echo
echo "--- HailoRT CLI ---"
if command -v hailortcli >/dev/null 2>&1; then
    hailortcli --version || true
else
    warn "hailortcli not found in PATH."
fi

echo
echo "--- PCIe ---"
if lspci -nn | grep -i hailo; then
    PCI_OK=1
else
    PCI_OK=0
    warn "No Hailo PCIe device is visible yet."
fi

echo
echo "--- Device nodes ---"
ls -l /dev/hailo* 2>/dev/null || warn "No /dev/hailo* device node is visible yet."

echo
echo "--- Python API ---"
PYTHON_OK=0
if "${HAILO_VENV}/bin/python" - <<'PY'
import numpy
import hailo_platform
assert numpy.__version__ == "1.26.4", numpy.__version__
print("numpy:", numpy.__version__)
print("hailo_platform import: OK")
print("module:", hailo_platform.__file__)
PY
then
    PYTHON_OK=1
fi

echo
echo "--- GStreamer ---"
GST_HAILONET=0
GST_HAILOTOOLS=0

if gst-inspect-1.0 hailonet >/dev/null 2>&1; then
    echo "hailonet  : OK"
    GST_HAILONET=1
else
    echo "hailonet  : NOT FOUND"
fi

if gst-inspect-1.0 hailotools >/dev/null 2>&1; then
    echo "hailotools: OK"
    GST_HAILOTOOLS=1
else
    echo "hailotools: NOT FOUND"
fi

echo
echo "--- Hailo device identification ---"
DEVICE_OK=0
if command -v hailortcli >/dev/null 2>&1; then
    if hailortcli fw-control identify; then
        DEVICE_OK=1
    else
        warn "hailortcli cannot identify the accelerator yet."
    fi
fi

# -----------------------------------------------------------------------------
# Summary
# -----------------------------------------------------------------------------

log "OrbiRob Hailo installation summary"

echo "Requested baseline:"
echo "  HailoRT              : ${EXPECTED_HAILORT}"
echo "  TAPPAS Core           : ${EXPECTED_TAPPAS_PY}"
echo "  TAPPAS Python         : ${EXPECTED_TAPPAS_PY} (if bundled)"
echo "  Python                : 3.12"
echo "  NumPy                 : 1.26.4"
echo "  setuptools            : 79.0.1"
echo "  Hailo Python venv     : ${HAILO_VENV}"
echo
echo "Convenience commands:"
echo "  hailo-python <script.py>"
echo "  hailo-verify"
echo

if (( DEVICE_OK == 1 && PYTHON_OK == 1 )); then
    echo "RESULT: Hailo installation is operational."
elif (( REBOOT_REQUIRED == 1 || PCI_OK == 0 )); then
    echo "RESULT: Software installation completed; reboot is required/recommended."
    echo
    echo "Run:"
    echo "  sudo reboot"
    echo
    echo "After reboot:"
    echo "  hailo-verify"
else
    echo "RESULT: Installation completed, but one or more verification checks failed."
    echo "Run:"
    echo "  hailo-verify"
fi

echo
echo "NOTE:"
echo "This script deliberately does not modify /boot/firmware/config.txt."
echo "For an official Raspberry Pi AI HAT+ this avoids changing PCIe boot settings"
echo "unless the hardware is actually not enumerated after reboot."
echo "The bundled hailo-apps directory is intentionally not installed by this script."
echo
